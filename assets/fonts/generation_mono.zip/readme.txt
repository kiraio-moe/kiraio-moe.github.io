You're free to use this typeface in non-commercial as well as commercial projects. Whenever possible credit the designers "Hoang Nguyen & David Gobber" properly.

Pay what you like:
https://nguyengobber.gumroad.com/l/generation-mono-typeface

More info:
https://nguyengobber.com/




